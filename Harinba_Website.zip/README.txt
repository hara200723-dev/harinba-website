HARINBA WEBSITE
================

This folder contains the first complete static website concept for Harinba.

Files:
- index.html — the website
- assets/ — your supplied Harinba core image and 8 concept images

To publish it publicly:
1. Upload the folder to a static website host such as GitHub Pages, Netlify, or another hosting provider.
2. Connect your domain (for example, www.harinba.com) through the host's domain/DNS settings.
3. Enable HTTPS.

The site is designed as:
Home → Concept → 8-Step Journey → Gallery → Featured Article.
